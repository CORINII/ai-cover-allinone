def get_or_train(user_id, voice_path):
    model_path = f"models/{user_id}.pth"
    print("✨ (예시) 목소리 학습 완료 또는 기존 모델 불러오기 완료")
    return model_path
