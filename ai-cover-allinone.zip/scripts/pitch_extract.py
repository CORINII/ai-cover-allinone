def extract(vocal_path):
    pitch_path = "temp/pitch.npy"
    print("✨ (예시) pitch 추출 완료")
    return pitch_path
