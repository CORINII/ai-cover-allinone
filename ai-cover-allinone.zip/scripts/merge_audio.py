def combine(vocal_path, inst_path, output_path):
    print("✨ (예시) vocal + inst 믹싱 완료")
    with open(output_path, "w") as f:
        f.write("fake audio content")
